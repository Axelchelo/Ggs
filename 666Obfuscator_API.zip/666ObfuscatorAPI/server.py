#!/usr/bin/env python3
import os, sys, json, shutil, tempfile, subprocess
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "engine"
CLI_DIR = ENGINE / "CLI"
DLL = CLI_DIR / "bin" / "Debug" / "net8.0" / "IronBrew2 CLI.dll"
if not DLL.is_file():
    # try Release
    alt = CLI_DIR / "bin" / "Release" / "net8.0" / "IronBrew2 CLI.dll"
    if alt.is_file():
        DLL = alt
PUBLIC = ROOT / "public"
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8080"))
MAX_SOURCE = int(os.environ.get("MAX_SOURCE", str(2 * 1024 * 1024)))

def find_dotnet():
    env = os.environ.get("DOTNET")
    if env and Path(env).exists():
        return env
    w = shutil.which("dotnet")
    if w:
        return w
    for p in ("/usr/share/dotnet/dotnet", "/tmp/dotnet/dotnet"):
        if Path(p).exists():
            return p
    raise RuntimeError("dotnet not found")

def obfuscate(source: str) -> str:
    if not source or not str(source).strip():
        raise ValueError("source vacío")
    if len(source) > MAX_SOURCE:
        raise ValueError(f"source demasiado grande (max {MAX_SOURCE})")
    work = Path(tempfile.mkdtemp(prefix="666obf_"))
    try:
        inp = work / "input.lua"
        inp.write_text(source, encoding="utf-8")
        env = os.environ.copy()
        dnet = find_dotnet()
        env["DOTNET_ROOT"] = str(Path(dnet).parent)
        env["PATH"] = f"/usr/bin:{env.get('PATH','')}"
        proc = subprocess.run(
            [dnet, str(DLL), str(inp)],
            cwd=str(CLI_DIR),
            env=env,
            capture_output=True,
            text=True,
            timeout=120,
        )
        out_file = CLI_DIR / "out.lua"
        if not out_file.is_file():
            err = (proc.stdout or "") + "\n" + (proc.stderr or "")
            raise RuntimeError(f"obfuscation failed:\n{err[-2000:]}")
        code = out_file.read_text(encoding="utf-8", errors="replace")
        try:
            out_file.unlink()
        except Exception:
            pass
        tdir = CLI_DIR / "temp"
        if tdir.is_dir():
            shutil.rmtree(tdir, ignore_errors=True)
        return code
    finally:
        shutil.rmtree(work, ignore_errors=True)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PUBLIC), **kwargs)

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_POST(self):
        if urlparse(self.path).path != "/api/obfuscate":
            self._json(404, {"ok": False, "error": "not found"})
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
            source = data.get("source") or data.get("code") or ""
            result = obfuscate(source)
            self._json(200, {"ok": True, "code": result, "size": len(result)})
        except Exception as e:
            self._json(400, {"ok": False, "error": str(e)})

    def do_GET(self):
        if self.path.startswith("/api/health"):
            self._json(200, {"ok": True, "service": "666Obfuscator API"})
            return
        if self.path in ("/", ""):
            self.path = "/index.html"
        return SimpleHTTPRequestHandler.do_GET(self)

def main():
    if not DLL.is_file():
        print("ERROR: missing", DLL, file=sys.stderr)
        sys.exit(1)
    print(f"666 Obfuscator API on http://{HOST}:{PORT}")
    HTTPServer((HOST, PORT), Handler).serve_forever()

if __name__ == "__main__":
    main()
