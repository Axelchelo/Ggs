# 666 Obfuscator API

## Railway
1. Sube esta carpeta a un repo GitHub
2. Railway → New Project → Deploy from GitHub
3. Settings → Networking → Generate Domain
4. Prueba: GET /api/health · POST /api/obfuscate {"source":"print(1)"}

## Local
Necesitas .NET 8 + lua5.1 (luac/lua/luajit en /usr/bin)
```bash
python3 server.py
```
